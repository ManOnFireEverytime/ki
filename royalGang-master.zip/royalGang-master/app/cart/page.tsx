"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { ArrowLeft, X } from "lucide-react";
import { useCart } from "@/app/Context/CartContext";

export default function CartPage() {
  const router = useRouter();
  const { cartItems, removeFromCart } = useCart();
  const [couponCode, setCouponCode] = useState("");

  const calculateSubtotal = (items) =>
    items.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const deliveryFee = 20500;
  const subtotal = calculateSubtotal(cartItems);
  const total = subtotal + deliveryFee;

  function goBack() {
    router.back();
  }

  return (
    <main className="flex h-dvh flex-col space-y-3 bg-background px-4 pb-10 pt-20 lg:space-y-6 lg:overflow-hidden lg:px-10">
      <button
        type="button"
        onClick={goBack}
        className="hover:text-primary mt-4 inline-flex items-center text-sm"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back
      </button>

      <div className="flex flex-grow flex-col gap-y-6 py-2 lg:flex-row lg:justify-between lg:gap-x-10 lg:divide-x lg:overflow-hidden lg:py-0">
        <div className="flex w-full flex-col">
          <div className="flex flex-col gap-6 overflow-hidden">
            <div className="text-muted-foreground grid grid-cols-[0.25fr_1fr_0.25fr] gap-4 text-center text-sm uppercase tracking-wide lg:grid-cols-[0.25fr_1fr_1fr_1fr_1fr_0.25fr]">
              <div className="col-start-2 col-end-3 text-customGrey">
                PRODUCT
              </div>

              <div className="hidden text-customGrey lg:col-start-3 lg:col-end-4 lg:block">
                Price
              </div>

              <div className="hidden text-customGrey lg:col-start-4 lg:col-end-5 lg:block">
                QUANTITY
              </div>

              <div className="col-start-3 text-customGrey lg:col-start-5 lg:col-end-6">
                SUBTOTAL
              </div>
            </div>

            <div className="h-full w-full overflow-auto">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="grid grid-cols-[0.25fr_1fr_0.25fr] items-center gap-4 border-b pb-4 text-center lg:grid-cols-[0.25fr_1fr_1fr_1fr_1fr_0.25fr]"
                >
                  <div className="relative h-20 w-20 bg-muted">
                    <Image
                      src={`https://backend.oceansteeze.com/products/${item.image}`}
                      alt={item.name}
                      fill
                      className="object-cover"
                    />
                  </div>

                  <div>
                    <h3 className="text-sm font-medium">{item.name}</h3>

                    <div className="text-muted-foreground flex flex-col justify-center gap-x-2 text-sm lg:flex-row lg:text-sm">
                      <p>
                        <span>Color:</span> <span>{item.color}</span>
                      </p>

                      <p className="block lg:hidden">
                        <span>Qty:</span> <span>{item.quantity}</span>
                      </p>
                    </div>
                  </div>

                  <div className="hidden lg:block">
                    <p>₦{item.price.toLocaleString()}</p>
                  </div>

                  <div className="hidden lg:block">
                    <p>{item.quantity}</p>
                  </div>

                  <div className="flex items-center justify-between">
                    <p className="flex-1 text-sm lg:text-base">
                      ₦{(item.price * item.quantity).toLocaleString()}
                    </p>
                  </div>

                  <button
                    type="button"
                    title="close"
                    onClick={() => removeFromCart(item.id)}
                    className="hidden p-2 text-red-500 hover:text-red-700 lg:block"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 flex w-full flex-col gap-y-4 overflow-hidden rounded-md transition-colors duration-150 focus-within:border-goldenRod lg:h-[50px] lg:w-[80%] lg:flex-row lg:border lg:bg-[#F4F4F4]">
            <input
              type="text"
              placeholder="Enter Coupon Code"
              value={couponCode}
              onChange={(e) => setCouponCode(e.target.value)}
              className="h-[50px] flex-grow rounded-sm border bg-[#F4F4F4] px-4 outline-none lg:h-full"
            />

            <button
              type="submit"
              className="h-[50px] min-w-[200px] rounded-md bg-saddleBrown text-sm text-white lg:h-full"
            >
              APPLY COUPON
            </button>
          </div>
        </div>

        <div className="h-[1px] w-full bg-muted lg:hidden"></div>

        <div className="basis-[30%] lg:px-6">
          <h1 className="mb-4 text-lg font-semibold text-customGrey">
            CART TOTALS
          </h1>

          <div className="space-y-2 lg:space-y-6">
            <div className="flex items-center justify-between">
              <h2>SUBTOTAL</h2>

              <p>₦{subtotal.toLocaleString()}</p>
            </div>

            <div className="border-t pt-2 lg:pt-4">
              <h2 className="mb-2 font-medium">DELIVERY</h2>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <h3 className="tracking-wide text-customGrey">
                    Delivery Fees:
                  </h3>

                  <p>₦{deliveryFee.toLocaleString()}</p>
                </div>

                <div className="flex justify-between">
                  <h3 className="tracking-wide text-customGrey">
                    Delivery Location:
                  </h3>

                  <p>ABUJA</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between border-t pt-4 font-semibold">
              <h2>TOTAL</h2>

              <p>₦{total.toLocaleString()}</p>
            </div>

            <button
              type="submit"
              className="h-[50px] w-full rounded-md bg-saddleBrown p-2 text-sm text-white"
            >
              PROCEED TO CHECKOUT
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}