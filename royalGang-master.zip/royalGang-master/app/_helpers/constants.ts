export const customerServiceEmail = "customerservice@royalgangchambers.com";
export const supportEmail = "support@royalgangchambers.com";
