"use client";

import { memo, useEffect, useState } from "react";
import Image from "next/image";
import { Minus, Plus } from "lucide-react";
import { useParams } from "next/navigation";
import PageWrapper from "@/app/_components/PageWrapper";
import { useCart } from "@/app/Context/CartContext";
// Import placeholder images for development/fallback
import tshirtFront from "../../../public/embrace.webp";
import tshirtBack from "../../../public/embrace.webp";
import signatureTank from "../../../public/signatureTank.webp";

// Define proper types
type ProductData = {
  id: string;
  product_name: string;
  price: string | number;
  description: string;
  colors: string;
  sizes: string;
  image1: string;
  image2?: string;
};

type ColorOption = {
  value: string;
  label: string;
};

type CardProps = {
  productInfo: {
    id: string;
    name: string;
    price: number;
    image: string;
  };
  ref?: React.Ref<HTMLDivElement>;
};

// Update Card component to match the expected props
const Card = ({ productInfo, ref }: CardProps) => {
  const backendBaseUrl = "https://backend.oceansteeze.com/products/";
  
  const handleRoute = () => {
    window.location.href = `/view/${productInfo.id}`;
  };

  return (
    <div
      onClick={handleRoute}
      ref={ref}
      className="group flex h-[384px] w-full flex-shrink-0 cursor-pointer flex-col text-black md:max-w-[250px] lg:max-w-[330px]"
    >
      <div className="relative w-full flex-grow">
        <Image
          fill
          src={productInfo.image.startsWith('http') ? productInfo.image : `${backendBaseUrl}${productInfo.image}`}
          className="z-10 object-contain transition-opacity duration-500 ease-in-out lg:group-hover:opacity-0"
          alt={`${productInfo.name} image`}
        />

        <Image
          fill
          src={productInfo.image.startsWith('http') ? productInfo.image : `${backendBaseUrl}${productInfo.image}`}
          className="hidden object-cover transition-opacity duration-500 ease-in-out lg:block"
          alt={`${productInfo.name} hover image`}
        />

        <div className="invisible absolute bottom-4 left-1/2 z-20 flex w-auto -translate-x-1/2 translate-y-5 scale-0 justify-center divide-x divide-black overflow-hidden rounded-lg border border-black text-center opacity-0 transition-[opacity_transform] duration-150 ease-linear lg:group-hover:visible lg:group-hover:translate-y-0 lg:group-hover:scale-100 lg:group-hover:opacity-100">
          <span className="cursor-default whitespace-nowrap px-2.5 py-1 text-center font-bold">
            Quick Add
          </span>

          <button type="button" className="quickAddBtn">
            S
          </button>

          <button type="button" className="quickAddBtn">
            M
          </button>

          <button type="button" className="quickAddBtn">
            L
          </button>

          <button type="button" className="quickAddBtn">
            XL
          </button>
        </div>
      </div>

      <div className="text-center">
        <p className="text-center font-bold">{productInfo.name}</p>
        <p>₦{new Intl.NumberFormat().format(productInfo.price)}</p>
      </div>
    </div>
  );
};

export default function Page() {
  const params = useParams();
  const productId = params.productId;
  const backendBaseUrl = "https://backend.oceansteeze.com/products/";
  const { addToCart } = useCart();

  // State declarations organized at the top
  const [product, setProduct] = useState<ProductData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [colors, setColors] = useState<ColorOption[]>([]);
  const [selectedColor, setSelectedColor] = useState<ColorOption | null>(null);
  const [sizes, setSizes] = useState<string[]>([]);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [cartMessage, setCartMessage] = useState("");
  const [similarProducts, setSimilarProducts] = useState<any[]>([]);
  

  // Fetch product data
  useEffect(() => {
    const fetchProduct = async () => {
      if (!productId) {
        setError("Invalid product ID");
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(
          `https://backend.oceansteeze.com/getProductById.php?id=${productId}`
        );
        const data = await response.json();

        if (data.status === "success" && data.data) {
          setProduct(data.data);

          // Parse colors from comma-separated string to array
          if (data.data.colors) {
            const colorArray = data.data.colors
              .split(",")
              .map((color: string) => color.trim());
            const colorOptions = colorArray.map((color: string) => ({
              value: color.toLowerCase(),
              label: color,
            }));
            setColors(colorOptions);
            // Set default color if available
            if (colorOptions.length > 0) {
              setSelectedColor(colorOptions[0]);
            }
          }

          // Parse sizes from comma-separated string to array
          if (data.data.sizes) {
            const sizeArray = data.data.sizes
              .split(",")
              .map((size: string) => size.trim());
            setSizes(sizeArray);
            // Set default size if available
            if (sizeArray.length > 0) {
              setSelectedSize(sizeArray[0]);
            }
          }

          // Also fetch related products
          fetchSimilarProducts(data.data.category_id);
        } else {
          setError("Product not found");
        }
      } catch (err) {
        setError("An error occurred while fetching product details");
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [productId]);

  // Fetch similar products
  const fetchSimilarProducts = async (categoryId: string) => {
    try {
      // Ideally fetch related products by category
      const response = await fetch(
        `https://backend.oceansteeze.com/getNewProducts.php`
      );
      const data = await response.json();

      if (data.status === "success") {
        setSimilarProducts(data.data.slice(0, 10)); // Limit to 10 products
      }
    } catch (err) {
      console.error("Failed to fetch similar products", err);
    }
  };

  // Event handlers
  const decreaseQuantity = () => {
    setQuantity((prev) => (prev > 1 ? prev - 1 : 1));
  };

  const increaseQuantity = () => {
    setQuantity((prev) => prev + 1);
  };

  const handleSizeSelect = (size: string) => {
    setSelectedSize(size);
  };
  const [count, setCount] = useState(1);
  const handleColorChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const colorValue = e.target.value;
    const selectedColorOption = colors.find(color => color.value === colorValue) || null;
    setSelectedColor(selectedColorOption);
  };

  

  const handleAddToCart = () => {
    if (!product) return;
    
    if (!selectedSize) {
      setCartMessage("Please select a size");
      setTimeout(() => {
        setCartMessage("");
      }, 3000);
      return;
    }
    const productDetails = {
        id: product.id,
        name: product.product_name,
        price: product.price,
        image: product.image1,
        color: selectedColor ? selectedColor.label : null,
        size: selectedSize,
    };

    addToCart(productDetails, quantity);

    // Add to cart logic would go here
    setCartMessage(
      `${quantity} ${product.product_name} (${selectedSize}, ${
        selectedColor ? selectedColor.label : "No Color"
      }) added to cart`
    );

    // Clear message after 3 seconds
    setTimeout(() => {
      setCartMessage("");
    }, 3000);
  };

  // Loading state
  if (loading) {
    return (
      <PageWrapper>
        <div className="flex items-center justify-center h-[500px]">
          <p>Loading product details...</p>
        </div>
      </PageWrapper>
    );
  }

  // Error state
  if (error) {
    return (
      <PageWrapper>
        <div className="flex items-center justify-center h-[500px]">
          <p className="text-red-500">{error}</p>
        </div>
      </PageWrapper>
    );
  }

  // No product state
  if (!product) {
    return (
      <PageWrapper>
        <div className="flex items-center justify-center h-[500px]">
          <p>Product not found</p>
        </div>
      </PageWrapper>
    );
  }

  return (
    <PageWrapper>
      <div className="flex flex-col items-center gap-y-8 pb-20 lg:flex-row">
        <div className="scrollbar flex w-full snap-x snap-mandatory overflow-auto lg:basis-1/2 lg:flex-col">
          {/* Product Images */}
          <div className="relative h-[500px] w-full flex-shrink-0 snap-start">
            <Image
              src={product.image1 ? `${backendBaseUrl}${product.image1}` : tshirtFront}
              fill
              alt="front view"
              className="object-contain"
            />
          </div>

          <div className="relative h-[500px] w-full flex-shrink-0 snap-start">
            <Image
              src={product.image2 ? `${backendBaseUrl}${product.image2}` : tshirtBack}
              fill
              alt="back view"
              className="object-contain"
            />
          </div>
        </div>

        <div className="basis-1/2 space-y-8 self-start p-2 lg:p-6">
          {/* Product Information */}
          <div className="space-y-2">
            <h1 className="text-2xl font-bold tracking-tight lg:text-5xl">
              {product.product_name}
            </h1>

            <p className="text-muted-foreground text-lg font-semibold lg:text-2xl">
              ₦ {typeof product.price === 'string' 
                ? Number(product.price).toLocaleString() 
                : product.price.toLocaleString()}
            </p>
          </div>

          <p className="text-muted-foreground w-full lg:max-w-[70%]">
            {product.description || "Product description unavailable"}
          </p>

          {/* Cart message alert */}
          {cartMessage && (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">
              {cartMessage}
            </div>
          )}

          <div className="space-y-6 lg:space-y-4">
            {/* Size Selection */}
            <div className="space-y-1">
              <h3 className="mb-2 text-sm font-medium">Size</h3>

              <div className="flex gap-3">
                {sizes.length > 0 ? (
                  sizes.map((size) => (
                    <button
                      type="button"
                      key={size}
                      className={`h-12 w-12 rounded-md ${
                        selectedSize === size
                          ? "bg-saddleBrown text-white"
                          : "bg-[#F9F1E7]"
                      } transition-colors duration-150`}
                      onClick={() => handleSizeSelect(size)}
                    >
                      {size}
                    </button>
                  ))
                ) : (
                  <p className="text-sm text-gray-500">No sizes available</p>
                )}
              </div>
            </div>

            {/* Color Selection */}
            <div className="space-y-1">
              <h3 className="mb-2 text-sm font-medium">Color</h3>

              {colors.length > 0 ? (
                <select
                  title="color"
                  className="w-[40%] rounded-md border p-2 text-left outline-none"
                  onChange={handleColorChange}
                  value={selectedColor?.value || ""}
                >
                  <option value="" disabled>
                    Choose a color
                  </option>
                  {colors.map((color) => (
                    <option key={color.value} value={color.value}>
                      {color.label}
                    </option>
                  ))}
                </select>
              ) : (
                <p className="text-sm text-gray-500">No colors available</p>
              )}
            </div>

            {/* Quantity and Add to Cart */}
            <div className="flex gap-4">
              <div className="flex items-center rounded-md border px-1">
                <button
                  type="button"
                  className="rounded-none"
                  onClick={decreaseQuantity}
                >
                  <Minus className="h-4 w-4" />
                </button>

                <div className="w-24 py-2 text-center">{quantity}</div>

                <button
                  title="increase"
                  type="button"
                  className="rounded-none"
                  onClick={increaseQuantity}
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>

              <button
                type="button"
                className="flex-1 rounded-md bg-saddleBrown text-white"
                onClick={handleAddToCart}
              >
                Add To Cart
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Related Products Section */}
      <div className="flex flex-col gap-y-4 border-t border-black pt-6">
        <h2 className="text-center text-sm font-bold text-muted">
          You May Also Like
        </h2>

        <div className="scrollbar-hidden flex gap-x-4 overflow-auto lg:px-0">
          {similarProducts.length > 0 ? (
            similarProducts.map((product) => (
              <Card
                key={product.id}
                productInfo={{
                  id: product.id,
                  name: product.product_name,
                  price: parseFloat(product.price),
                  image: product.image1
                }}
              />
            ))
          ) : (
            // Fallback to static items if no similar products are available
            Array.from({ length: 4 }).map((_, i) => (
              <Card
                key={i}
                productInfo={{
                  id: `fallback-${i}`,
                  name: "Sample Product",
                  price: 10000,
                  image: i % 2 ? signatureTank.src : tshirtFront.src
                }}
              />
            ))
          )}
        </div>
      </div>
    </PageWrapper>
  );
}