(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_icon_png_mjs_797d15._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_icon_png_mjs_797d15._.js",
  "chunks": [
    "static/chunks/_ca681a._.js"
  ],
  "source": "dynamic"
});
