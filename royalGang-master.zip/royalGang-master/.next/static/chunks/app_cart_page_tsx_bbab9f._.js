(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_cart_page_tsx_bbab9f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_cart_page_tsx_bbab9f._.js",
  "chunks": [
    "static/chunks/_6e0c6e._.js"
  ],
  "source": "dynamic"
});
