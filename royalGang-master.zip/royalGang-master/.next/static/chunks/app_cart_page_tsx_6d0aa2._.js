(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_cart_page_tsx_6d0aa2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_cart_page_tsx_6d0aa2._.js",
  "chunks": [
    "static/chunks/_2f5a80._.js"
  ],
  "source": "dynamic"
});
