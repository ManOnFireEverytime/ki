(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_view_[productId]_page_tsx_bbab9f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_view_[productId]_page_tsx_bbab9f._.js",
  "chunks": [
    "static/chunks/_0c7a85._.js"
  ],
  "source": "dynamic"
});
