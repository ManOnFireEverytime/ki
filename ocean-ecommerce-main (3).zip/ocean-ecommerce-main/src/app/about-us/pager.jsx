// import React from "react";
// import "./page.css"
// import Navbar from "@/Components/Navbar/Navbar";
// import Footer from "@/Components/Footer/Footer";

// function About() {
//     return (
//       <div className="about__container">
//         <div className="about__container-navbar">
//           <Navbar />
//         </div>
//         <div className="about__container-hero">
//           <img src="/heroImg2.png" alt="" />
//         </div>
//         <div className="about__container-section2">
//           <div className="about__container-section2_text">
//             <p>
//               Russell Westbrook is a mosaic of his experiences. He is hardship
//               and luxury. He is basketball and fashion. He is brodie and dad. He
//               is inspired and inspiring. He is why not and why how. Russell is
//               from Los Angeles. He is a founder and creative director. He is
//               honoring the gift.  He is Honor The Gift.
//             </p>
//           </div>
//           <div className="about__container-section2_images">
//             <img src="/about1.png" alt="" />
//             <div className="group">
//               <img src="/about2.png" alt="" />
//               <img src="/about3.png" alt="" />
//             </div>
//           </div>
//         </div>
//             <div className="about__container-footer">
//                 <Footer />
//             </div>
//       </div>
//     )
// }

// export default About